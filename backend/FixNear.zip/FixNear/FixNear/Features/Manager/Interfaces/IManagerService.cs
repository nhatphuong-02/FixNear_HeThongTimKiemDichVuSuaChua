﻿using FixNear.Features.Manager.DTOs;

namespace FixNear.Features.Manager.Interfaces;

public interface IManagerService
{
    #region Quản lý ảnh cửa hàng

    Task<object> GetShopImagesAsync(
        int userId,
        int shopId);

    Task<object?> AddShopImageAsync(
        int userId,
        int shopId,
        ShopImageDto dto);

    Task<bool> UpdateShopImageAsync(
        int userId,
        int shopId,
        int imageId,
        ShopImageDto dto);

    Task<bool> DeleteShopImageAsync(
        int userId,
        int shopId,
        int imageId);

    Task<bool> SetPrimaryImageAsync(
        int userId,
        int shopId,
        int imageId);

    #endregion

    #region Quản lý dịch vụ của cửa hàng

    Task<object> GetSystemServicesAsync();

    Task<object?> GetShopServicesAsync(
        int userId,
        int shopId);

    Task<object?> GetShopServiceDetailAsync(
        int userId,
        int shopId,
        int shopServiceId);

    Task<object?> AddShopServiceAsync(
        int userId,
        int shopId,
        AddShopServiceDto dto);

    Task<bool> UpdateShopServiceAsync(
        int userId,
        int shopId,
        int shopServiceId,
        UpdateShopServiceDto dto);

    Task<bool> SetShopServiceStatusAsync(
        int userId,
        int shopId,
        int shopServiceId,
        bool isActive);

    #endregion

    #region Quản lý giá dịch vụ

    Task<object?> GetServicePricesAsync(
        int userId,
        int shopId,
        bool includeHistory);

    Task<object?> GetServicePriceAsync(
        int userId,
        int shopId,
        int servicePriceId);

    Task<object?> AddServicePriceAsync(
        int userId,
        int shopId,
        ServicePriceDto dto);

    Task<object?> UpdateServicePriceAsync(
        int userId,
        int shopId,
        int servicePriceId,
        UpdateServicePriceDto dto);

    #endregion

    #region Xem danh sách yêu cầu sửa chữa

    Task<object?> GetRepairRequestsAsync(
        int managerId,
        int shopId);

    #endregion

    // Chi tiết Repair cho Manager đã được cấp quyền Shop.
    Task<object?> GetRepairRequestDetailAsync(
        int userId, int shopId, int repairRequestId);

    #region Tiếp nhận yêu cầu

    Task<ManagerActionResult> AcceptRepairRequestAsync(
        int managerId,
        int shopId,
        int repairRequestId,
        AcceptRepairRequestDto dto);

    #endregion

    #region Từ chối yêu cầu

    Task<ManagerActionResult> RejectRepairRequestAsync(
        int managerId,
        int shopId,
        int repairRequestId,
        RejectRepairRequestDto dto);

    #endregion

    #region Phân công kỹ thuật viên

    Task<ManagerActionResult> AssignRepairTechnicianAsync(
        int managerId,
        int shopId,
        AssignTechnicianDto dto);

    #endregion

    #region Đổi kỹ thuật viên

    Task<ManagerActionResult> ReassignRepairTechnicianAsync(
        int managerId,
        int shopId,
        int assignmentId,
        ReassignTechnicianDto dto);

    #endregion

    #region Lịch sửa chữa

    Task<object?> GetManagerRepairSchedulesAsync(
        int managerId,
        int shopId,
        bool includeHistory);

    Task<ManagerActionResult> CreateManagerRepairScheduleAsync(
        int managerId,
        int shopId,
        CreateRepairScheduleDto dto);

    #endregion
}
