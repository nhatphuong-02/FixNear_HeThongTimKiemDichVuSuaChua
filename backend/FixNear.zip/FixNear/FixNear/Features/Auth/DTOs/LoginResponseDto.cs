﻿namespace FixNear.Features.Auth.DTOs
{
    public class LoginResponseDto
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public int RoleType { get; set; }
        public string Token { get; set; } = null!;
    }
}
