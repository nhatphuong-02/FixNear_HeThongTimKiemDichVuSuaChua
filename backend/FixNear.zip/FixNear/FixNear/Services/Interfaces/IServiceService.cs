﻿using FixNear.DTOs.Service;
using FixNear.DTOs.ServiceCategory;

namespace FixNear.Services.Interfaces
{
    public interface IServiceService
    {
        Task<List<ServiceCategoryResponeDto>> GetCategoriesAsync();
        Task<ServiceCategoryDetailDto> GetCategoryByIdAsync(int categoryId);
    }
}
