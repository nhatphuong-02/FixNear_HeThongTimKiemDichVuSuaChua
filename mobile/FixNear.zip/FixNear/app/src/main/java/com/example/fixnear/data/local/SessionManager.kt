package com.example.fixnear.data.local

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    companion object {
        private const val PREF_NAME = "FixNearSession"

        private const val KEY_USER_ID = "user_id"
        private const val KEY_FULL_NAME = "full_name"
        private const val KEY_ROLE_TYPE = "role_type"
        private const val KEY_TOKEN = "token"
    }

    private val preferences: SharedPreferences =
        context.getSharedPreferences(
            PREF_NAME,
            Context.MODE_PRIVATE
        )

    // Lưu thông tin đăng nhập
    fun saveLogin(
        userId: Int,
        fullName: String,
        roleType: Int,
        token: String
    ) {
        preferences.edit().apply {
            putInt(KEY_USER_ID, userId)
            putString(KEY_FULL_NAME, fullName)
            putInt(KEY_ROLE_TYPE, roleType)
            putString(KEY_TOKEN, token)
            apply()
        }
    }

    // Lấy ID người dùng
    fun getUserId(): Int {
        return preferences.getInt(KEY_USER_ID, -1)
    }

    // Lấy họ tên
    fun getFullName(): String? {
        return preferences.getString(KEY_FULL_NAME, null)
    }

    // Lấy loại tài khoản

    fun getRoleType(): Int {
        return preferences.getInt(KEY_ROLE_TYPE, -1)
    }


    // Lấy JWT Token
    fun getToken(): String? {
        return preferences.getString(KEY_TOKEN, null)
    }

    // Kiểm tra đã đăng nhập hay chưa
    fun isLoggedIn(): Boolean {
        return !getToken().isNullOrBlank()
    }

    // Xóa toàn bộ phiên đăng nhập
    fun clearSession() {
        preferences.edit().clear().apply()
    }
}